
var TemplateProperty = require("./base/entity")("service_template_properties");


module.exports = TemplateProperty;