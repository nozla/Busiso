let EventEmitter = require('events').EventEmitter;

let emitter = new EventEmitter();

module.exports = emitter;
